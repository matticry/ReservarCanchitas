// Selecciona el contenedor de fondo y establece el estilo de fondo
const backgroundContainer = document.querySelector('.background-container');
backgroundContainer.style.backgroundImage = 'url("../Images/hola.jpg")';
backgroundContainer.style.backgroundSize = 'cover';
backgroundContainer.style.backgroundPosition = 'center';